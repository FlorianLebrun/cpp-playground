#pragma once
#include <string>
#include <vector>
#include <list>
#include <map>

class QString : public std::string {
public:
   template <typename... Ta> QString(Ta... t)
      : string(t...) {
   }
};

template <typename T>
class QVector : public std::vector<T> {
public:
   template <typename... Ta> QVector(Ta... t)
      : vector(t...) {
   }
   size_t length() { return this->size(); }
};

template <typename T>
class QList : public std::list<T> {
public:
   template <typename... Ta> QList(Ta... t)
      : list(t...) {
   }
};

template <typename Tx, typename Ty>
class QMap : public std::map<Tx, Ty> {
public:
   template <typename... Ta> QMap(Ta... t)
      : map(t...) {
   }
};

template <typename Tx, typename Ty>
class QPair : public std::pair<Tx, Ty> {
public:
   template <typename... Ta> QPair(Ta... t)
      : pair(t...) {
   }
};

typedef QList<QString> QStringList;
typedef char QChar;
